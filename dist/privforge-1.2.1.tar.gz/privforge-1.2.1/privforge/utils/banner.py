from privforge.utils import (
    clear as c, 
    hero_cli as hc
)

def banner():
    c.clear()
    hc.hero()